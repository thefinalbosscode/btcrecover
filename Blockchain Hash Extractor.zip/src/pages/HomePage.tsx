import { useState, useEffect } from 'react';
import { extractSecondPasswordHash } from '@/lib/crypto-utils';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { FileUploader } from '@/components/FileUploader';
import { PasswordInput } from '@/components/PasswordInput';
import { ProcessIndicator } from '@/components/ProcessIndicator';
import { HashResult } from '@/components/HashResult';
import { InfoSection } from '@/components/InfoSection';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Cpu, Key } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

function HomePage() {
  const [walletData, setWalletData] = useState<any>(null);
  const [password, setPassword] = useState('');
  const [processing, setProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');
  const [progressPercentage, setProgressPercentage] = useState(0);
  const [result, setResult] = useState<{ hash: string; version: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // Reset all states
  const handleReset = () => {
    setWalletData(null);
    setPassword('');
    setProcessing(false);
    setProcessingStatus('');
    setProgressPercentage(0);
    setResult(null);
    setError(null);
  };
  
  // Handle file upload
  const handleFileLoaded = (data: any) => {
    setWalletData(data);
    setError(null);
    
    // Basic validation to ensure it looks like a blockchain wallet
    if (!data || (!data.guid && !data.payload)) {
      setError('The file doesn\'t appear to be a valid Blockchain.com wallet backup.');
      return;
    }
    
    toast({
      title: "Wallet file loaded",
      description: "Please enter your main wallet password to continue.",
    });
  };

  // Process wallet and extract hash
  const processWallet = async () => {
    if (!walletData || !password) {
      setError('Please provide both wallet file and password.');
      return;
    }

    setProcessing(true);
    setError(null);
    setResult(null);
    
    try {
      // Simulated progress for better UX
      setProcessingStatus('Analyzing wallet format...');
      setProgressPercentage(10);
      await simulateProgress(500);
      
      setProcessingStatus('Extracting encryption parameters...');
      setProgressPercentage(30);
      await simulateProgress(800);
      
      setProcessingStatus('Attempting decryption...');
      setProgressPercentage(60);
      await simulateProgress(1000);
      
      setProcessingStatus('Retrieving second password hash...');
      setProgressPercentage(85);
      
      // Actual extraction process
      const extractedResult = await extractSecondPasswordHash(walletData, password);
      
      setProgressPercentage(100);
      setProcessingStatus('Hash extracted successfully!');
      setResult(extractedResult);
      
      toast({
        title: "Success!",
        description: "Second password hash successfully extracted.",
        variant: "default",
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      toast({
        title: "Extraction Failed",
        description: err instanceof Error ? err.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };
  
  // Helper function to simulate progressive steps
  const simulateProgress = (ms: number) => {
    return new Promise(resolve => setTimeout(resolve, ms));
  };
  
  // Clear memory when component unmounts
  useEffect(() => {
    return () => {
      setWalletData(null);
      setPassword('');
      setResult(null);
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background font-sans">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Introduction and Info Section */}
          <section>
            <InfoSection />
          </section>
          
          {/* Main Processing Section */}
          <section>
            {!result ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Key className="h-5 w-5 text-primary" />
                    Second Password Hash Extractor
                  </CardTitle>
                  <CardDescription>
                    Upload your wallet file and enter your main password to extract the second password hash
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  {/* File Upload Section */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Step 1: Upload Wallet File</h3>
                    <FileUploader onFileLoaded={handleFileLoaded} isProcessing={processing} />
                  </div>
                  
                  {/* Password Input Section */}
                  {walletData && (
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">Step 2: Enter Main Wallet Password</h3>
                      <PasswordInput 
                        value={password} 
                        onChange={setPassword}
                        isProcessing={processing}
                      />
                    </div>
                  )}
                  
                  {/* Processing Status */}
                  {processing && (
                    <div className="mt-6">
                      <ProcessIndicator 
                        status={processingStatus}
                        progress={progressPercentage}
                      />
                    </div>
                  )}
                  
                  {/* Error Display */}
                  {error && (
                    <Alert variant="destructive" className="mt-4">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  {/* Action Button */}
                  <div className="pt-4 flex justify-end">
                    <Button
                      onClick={processWallet}
                      disabled={!walletData || !password || processing}
                      className="gap-2"
                    >
                      <Cpu className={`h-4 w-4 ${processing ? 'animate-spin' : ''}`} />
                      {processing ? 'Processing...' : 'Extract Hash'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <HashResult 
                hash={result.hash} 
                walletVersion={result.version}
                onReset={handleReset} 
              />
            )}
          </section>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default HomePage;