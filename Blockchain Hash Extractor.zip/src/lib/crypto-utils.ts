// Utility functions for blockchain wallet decryption and hash extraction

// Base64 decoding function
export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

// ArrayBuffer to Base64
export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const binary = String.fromCharCode(...new Uint8Array(buffer));
  return btoa(binary);
}

// PBKDF2 key derivation
export async function deriveKey(
  password: string, 
  salt: ArrayBuffer, 
  iterations: number, 
  keyLength: number
): Promise<ArrayBuffer> {
  const encoder = new TextEncoder();
  const passwordBuffer = encoder.encode(password);
  
  // Import the password as a raw key
  const importedKey = await crypto.subtle.importKey(
    'raw',
    passwordBuffer,
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  
  // Derive bits using PBKDF2
  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: iterations,
      hash: 'SHA-1'
    },
    importedKey,
    keyLength * 8
  );
  
  return derivedBits;
}

// AES-256-CBC decryption
export async function decryptAESCBC(
  ciphertext: ArrayBuffer, 
  key: ArrayBuffer,
  iv: ArrayBuffer
): Promise<ArrayBuffer> {
  // Import the key
  const importedKey = await crypto.subtle.importKey(
    'raw',
    key,
    { name: 'AES-CBC', length: 256 },
    false,
    ['decrypt']
  );
  
  // Decrypt the ciphertext
  try {
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-CBC', iv: new Uint8Array(iv) },
      importedKey,
      ciphertext
    );
    return decrypted;
  } catch (error) {
    throw new Error('Decryption failed: Incorrect password or corrupted data');
  }
}

// Function to extract hash from wallet
export async function extractSecondPasswordHash(
  walletData: any, 
  password: string
): Promise<{ hash: string; version: string }> {
  try {
    // Detect wallet version
    const version = detectWalletVersion(walletData);
    
    // Different extraction strategies based on wallet version
    switch(version) {
      case 'v3':
        return await extractV3Hash(walletData, password);
      case 'v2':
        return await extractV2Hash(walletData, password);
      case 'v1':
        return await extractV1Hash(walletData, password);
      default:
        throw new Error(`Unsupported wallet version: ${version}`);
    }
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Unknown error during hash extraction');
  }
}

// Detect wallet version
function detectWalletVersion(walletData: any): string {
  if (walletData.version) {
    if (typeof walletData.version === 'number') {
      return `v${walletData.version}`;
    }
    return walletData.version;
  }
  
  // Legacy wallet detection
  if (walletData.payload && walletData.payload.version) {
    return `v${walletData.payload.version}`;
  }
  
  // Very old wallets might not have explicit version
  if (walletData.guid && !walletData.version) {
    return 'v1';
  }
  
  throw new Error('Unknown wallet format: Cannot detect version');
}

// Extract hash from v3 wallet
async function extractV3Hash(walletData: any, password: string): Promise<{ hash: string; version: string }> {
  // Check if second password is enabled
  if (!walletData.options || !walletData.options.pbkdf2_iterations_second_password) {
    throw new Error('This wallet does not have a second password enabled');
  }
  
  // Get encryption parameters
  const salt = base64ToArrayBuffer(walletData.options.salt_second_password || walletData.options.salt);
  const iterations = walletData.options.pbkdf2_iterations_second_password || walletData.options.pbkdf2_iterations;
  
  // If we have direct hash, return it
  if (walletData.options.secondPasswordHash) {
    return { 
      hash: walletData.options.secondPasswordHash, 
      version: 'v3'
    };
  }
  
  // Otherwise return the salt and iterations for offline cracking
  return {
    hash: `salt:${arrayBufferToBase64(salt)},iterations:${iterations}`,
    version: 'v3'
  };
}

// Extract hash from v2 wallet
async function extractV2Hash(walletData: any, password: string): Promise<{ hash: string; version: string }> {
  // V2 wallets typically have a payload structure
  const payload = walletData.payload || walletData;
  
  // Check if second password is enabled
  if (!payload.double_encryption) {
    throw new Error('This wallet does not have a second password enabled');
  }
  
  // Get the hash or parameters
  if (payload.dpasswordhash) {
    return {
      hash: payload.dpasswordhash,
      version: 'v2'
    };
  }
  
  return {
    hash: `Wallet v2 second password hash cannot be directly extracted`,
    version: 'v2'
  };
}

// Extract hash from v1 wallet
async function extractV1Hash(walletData: any, password: string): Promise<{ hash: string; version: string }> {
  // V1 wallets are very old and have a different structure
  if (!walletData.double_encryption) {
    throw new Error('This wallet does not have a second password enabled');
  }
  
  return {
    hash: `Legacy wallet format (v1) detected. Hash extraction requires specialized tools.`,
    version: 'v1'
  };
}