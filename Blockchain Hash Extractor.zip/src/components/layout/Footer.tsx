import { Shield, Lock } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-border mt-10 py-6 bg-secondary">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <Lock className="h-4 w-4 text-primary" />
            <p className="text-sm text-muted-foreground">
              All processing happens in your browser. No data is sent to any server.
            </p>
          </div>
          <div className="text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              <span>Secure Client-Side Processing</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}