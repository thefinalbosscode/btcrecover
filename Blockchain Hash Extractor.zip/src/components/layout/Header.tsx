import { Shield } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-primary text-white py-4 border-b border-primary/20">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-6 w-6" />
          <h1 className="text-xl font-bold font-sans">Blockchain Second Password Hash Extractor</h1>
        </div>
        <div className="text-sm font-semibold text-primary-foreground/80">
          Secure Client-Side Tool
        </div>
      </div>
    </header>
  );
}