import { Progress } from '@/components/ui/progress';

interface ProcessIndicatorProps {
  status: string;
  progress: number;
}

export function ProcessIndicator({ status, progress }: ProcessIndicatorProps) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <p className="text-sm font-medium">{status}</p>
        <span className="text-sm text-muted-foreground">{progress}%</span>
      </div>
      <Progress value={progress} className="h-2" />
    </div>
  );
}