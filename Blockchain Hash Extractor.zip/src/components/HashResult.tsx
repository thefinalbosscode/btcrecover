import { useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '@/components/ui/card';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';

interface HashResultProps {
  hash: string;
  walletVersion: string;
  onReset: () => void;
}

export function HashResult({ hash, walletVersion, onReset }: HashResultProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(hash);
      setCopied(true);
      
      toast({
        title: "Hash copied to clipboard",
        description: "You can now use this with password recovery tools",
      });
      
      setTimeout(() => {
        setCopied(false);
      }, 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please select and copy the text manually",
        variant: "destructive"
      });
    }
  };
  
  return (
    <Card className="border-success/30 bg-success/5">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-success">
          <Check className="h-5 w-5" /> Hash Successfully Extracted
        </CardTitle>
        <CardDescription>
          Wallet version: <span className="font-semibold">{walletVersion}</span>
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Alert className="bg-card border-muted">
          <AlertTitle>Second Password Hash</AlertTitle>
          <AlertDescription className="mt-2">
            <div className="relative">
              <pre className="bg-black/5 p-3 rounded-md text-xs md:text-sm overflow-x-auto whitespace-pre-wrap break-all">
                {hash}
              </pre>
            </div>
          </AlertDescription>
        </Alert>
        
        <div className="mt-4 space-y-2">
          <h4 className="text-sm font-semibold">Next Steps:</h4>
          <ol className="text-sm text-muted-foreground list-decimal pl-5 space-y-1">
            <li>Copy this hash value</li>
            <li>Use a password recovery tool that supports Blockchain.com second password recovery</li>
            <li>Input this hash value when prompted by the recovery tool</li>
          </ol>
        </div>
      </CardContent>
      
      <CardFooter className="flex flex-col sm:flex-row gap-2">
        <Button 
          className="w-full sm:w-auto" 
          onClick={copyToClipboard}
          variant="outline"
        >
          {copied ? (
            <>
              <Check className="mr-2 h-4 w-4" /> Copied
            </>
          ) : (
            <>
              <Copy className="mr-2 h-4 w-4" /> Copy to Clipboard
            </>
          )}
        </Button>
        
        <Button 
          className="w-full sm:w-auto" 
          onClick={onReset}
          variant="secondary"
        >
          Process Another Wallet
        </Button>
      </CardFooter>
    </Card>
  );
}