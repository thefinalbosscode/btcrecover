import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Eye, EyeOff } from 'lucide-react';

interface PasswordInputProps {
  onChange: (value: string) => void;
  value: string;
  isProcessing: boolean;
}

export function PasswordInput({ onChange, value, isProcessing }: PasswordInputProps) {
  const [showPassword, setShowPassword] = useState(false);
  
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  
  return (
    <div className="space-y-2">
      <div className="space-y-1">
        <Label htmlFor="password">Main Wallet Password</Label>
        <div className="relative">
          <Input
            id="password"
            type={showPassword ? 'text' : 'password'}
            placeholder="Enter your main wallet password"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={isProcessing}
            className="pr-10"
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={togglePasswordVisibility}
            className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
            disabled={isProcessing}
          >
            {showPassword ? (
              <EyeOff className="h-4 w-4 text-muted-foreground" />
            ) : (
              <Eye className="h-4 w-4 text-muted-foreground" />
            )}
          </Button>
        </div>
      </div>
      <p className="text-xs text-muted-foreground">
        This is your main wallet password, not the second password you're trying to recover
      </p>
    </div>
  );
}