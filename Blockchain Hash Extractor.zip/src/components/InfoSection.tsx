import { AlertCircle, Key, ShieldCheck, Info } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

export function InfoSection() {
  return (
    <div className="space-y-6">
      <Alert variant="default" className="border-info/30 bg-info/5">
        <Info className="h-4 w-4 text-info" />
        <AlertTitle>Tool Purpose</AlertTitle>
        <AlertDescription>
          This tool helps extract hash information from Blockchain.com wallet files when you've forgotten your second password.
          The extracted hash can be used with password recovery tools to attempt recovery of your second password.
        </AlertDescription>
      </Alert>
      
      <Alert variant="default" className="border-primary/30 bg-primary/5">
        <ShieldCheck className="h-4 w-4 text-primary" />
        <AlertTitle>Security Notice</AlertTitle>
        <AlertDescription>
          <p className="mb-2">All processing is done in your browser. Your wallet file and password are never transmitted to any server.</p>
          <ul className="list-disc pl-5 text-sm space-y-1">
            <li>Do not share your wallet file or main password with anyone</li>
            <li>Ensure you're using this tool on a secure device</li>
            <li>Close this page after use</li>
          </ul>
        </AlertDescription>
      </Alert>
      
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="instructions">
          <AccordionTrigger className="text-left">
            <div className="flex items-center gap-2">
              <Key className="h-4 w-4 text-primary" />
              <span>Step-by-Step Instructions</span>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <ol className="list-decimal pl-5 text-sm space-y-2 text-muted-foreground">
              <li>Upload your Blockchain.com wallet backup file (JSON format)</li>
              <li>Enter your main wallet password (not the second password)</li>
              <li>Click "Extract Hash" to process your wallet file</li>
              <li>Copy the extracted hash information</li>
              <li>Use the hash with compatible password recovery tools</li>
            </ol>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="faq">
          <AccordionTrigger className="text-left">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-primary" />
              <span>Frequently Asked Questions</span>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 text-sm">
              <div>
                <h4 className="font-medium">Which wallet versions are supported?</h4>
                <p className="text-muted-foreground">This tool supports Blockchain.com wallet versions v1 through v3.</p>
              </div>
              
              <div>
                <h4 className="font-medium">What if I get an error?</h4>
                <p className="text-muted-foreground">Common errors include incorrect main password, corrupted wallet file, or a wallet without a second password.</p>
              </div>
              
              <div>
                <h4 className="font-medium">Can this tool recover my second password directly?</h4>
                <p className="text-muted-foreground">No, this tool only extracts the hash. You'll need specialized password recovery software to find your actual second password.</p>
              </div>
              
              <div>
                <h4 className="font-medium">Where can I find my wallet backup file?</h4>
                <p className="text-muted-foreground">In the Blockchain.com web wallet, go to Settings > Backup > Download Backup File.</p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="technical">
          <AccordionTrigger className="text-left">
            <div className="flex items-center gap-2">
              <Info className="h-4 w-4 text-primary" />
              <span>Technical Details</span>
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>This tool implements client-side cryptography with the following:</p>
              <ul className="list-disc pl-5 space-y-1">
                <li>AES-256 CBC/OFB decryption</li>
                <li>PBKDF2 key derivation function</li>
                <li>Base64 encoding/decoding</li>
                <li>Multiple wallet version support</li>
              </ul>
              <p className="mt-2">The extraction process attempts multiple decryption strategies based on the wallet version to find the second password hash.</p>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}