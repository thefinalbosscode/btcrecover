import { useState, useRef } from 'react';
import { Upload, X, FileJson } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

interface FileUploaderProps {
  onFileLoaded: (data: any) => void;
  isProcessing: boolean;
}

export function FileUploader({ onFileLoaded, isProcessing }: FileUploaderProps) {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Handle drag events
  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  // Handle drop event
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  // Handle file input change
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Process the selected file
  const processFile = (file: File) => {
    // Check file size
    if (file.size > 64 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Maximum file size is 64MB.",
        variant: "destructive"
      });
      return;
    }

    setFile(file);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        if (event.target?.result) {
          const result = JSON.parse(event.target.result as string);
          onFileLoaded(result);
        }
      } catch (error) {
        toast({
          title: "Invalid file format",
          description: "Please upload a valid Blockchain.com wallet file (JSON format).",
          variant: "destructive"
        });
        setFile(null);
      }
    };
    
    reader.onerror = () => {
      toast({
        title: "Error reading file",
        description: "There was a problem reading the file.",
        variant: "destructive"
      });
      setFile(null);
    };
    
    reader.readAsText(file);
  };

  // Handle click on the drop area
  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  // Clear selected file
  const clearFile = () => {
    setFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full">
      <input
        ref={fileInputRef}
        type="file"
        accept=".json,application/json"
        className="hidden"
        onChange={handleChange}
        disabled={isProcessing}
      />
      
      <Card className={`border-2 ${dragActive ? 'border-primary border-dashed bg-primary/5' : 'border-border'}`}>
        <CardContent className="p-6">
          {!file ? (
            <div
              className="flex flex-col items-center justify-center gap-4 py-10 text-center"
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <div className="rounded-full bg-secondary p-3">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-lg font-medium">Drag and drop your wallet file</p>
                <p className="text-sm text-muted-foreground mt-1">
                  or click to browse (JSON format)
                </p>
              </div>
              <Button 
                variant="secondary" 
                onClick={onButtonClick}
                disabled={isProcessing}
              >
                Select File
              </Button>
            </div>
          ) : (
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-2">
                <FileJson className="h-8 w-8 text-primary" />
                <div>
                  <p className="font-medium">{file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(file.size / 1024).toFixed(1)} KB
                  </p>
                </div>
              </div>
              {!isProcessing && (
                <Button 
                  size="icon"
                  variant="ghost"
                  onClick={clearFile}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}