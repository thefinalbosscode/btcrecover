# Blockchain Second Password Hash Extractor

## Project Description
A specialized utility tool for Bitcoin wallet recovery that provides a secure interface for extracting hash information from encrypted blockchain wallet files. This application helps users recover their second passwords for Blockchain.com wallets by extracting the necessary hash information needed for password recovery tools.

## Key Features
- **Secure Client-Side Processing**: All cryptographic operations happen in the browser, no data sent to servers
- **Multiple Wallet Formats**: Support for Blockchain.com wallet versions v1 through v3
- **Professional Interface**: Enterprise design style with security-focused UI elements
- **Interactive Guidance**: Step-by-step instructions and FAQ for user assistance
- **Security Focused**: Clear security notices and best practices for sensitive operations

## File Structure

```
src/
├── components/
│   ├── layout/
│   │   ├── Header.tsx          # Application header component
│   │   └── Footer.tsx          # Application footer with security notices
│   ├── ui/                     # shadcn/ui components (unchanged)
│   ├── FileUploader.tsx        # Drag-and-drop file upload component
│   ├── PasswordInput.tsx       # Secure password input with show/hide toggle
│   ├── ProcessIndicator.tsx    # Progress bar for extraction process
│   ├── HashResult.tsx          # Result display with copy functionality
│   └── InfoSection.tsx         # Information, FAQ, and technical details
├── lib/
│   └── crypto-utils.ts         # Cryptographic utilities for wallet decryption
├── pages/
│   ├── HomePage.tsx            # Main application page
│   └── NotFoundPage.tsx        # 404 page
├── hooks/                      # React hooks (from template)
├── App.tsx                     # Application routes
├── index.css                   # Global styles and design system
└── main.tsx                    # Application entry point
```

## Technologies
- **Frontend**: React + TypeScript + Vite
- **UI**: Tailwind CSS + shadcn/ui components
- **Cryptography**: Web Crypto API for AES decryption, PBKDF2
- **State Management**: React useState/useEffect hooks

## Design System
- **Primary Color**: Navy Blue (#1A365D)
- **Accent Color**: Orange (#DD6B20)
- **Background**: Light Gray (#F7FAFC)
- **Typography**: Source Sans Pro